# Java Quiz Game
This is a java quiz game created by integrating json-simple in java using JSON manipulation techniques.  <br />
- Here, admin can create a **Quiz Bank** by adding mcq type questions and add relevant question options.  <br />
Adding question to the **Quiz Bank** is demonstrated below: <br />

https://user-images.githubusercontent.com/55280106/182017628-3618954b-ac35-4d37-a282-7615f0dbe701.mov 

- User can give quiz and need to answer five questions where the five question will be extracted from the 
Quiz Bank randomnly.  <br /> After answering five questions the result will be displayed to the user.  <br />
Giving quiz by the user is demonstrated below:



https://user-images.githubusercontent.com/55280106/182017941-a66d0d04-d6b8-44e6-9189-9d50d309e0be.mov

